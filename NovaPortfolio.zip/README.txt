Nova Portfolio Template

Description:
A clean and responsive HTML5/CSS3 portfolio template ideal for designers, developers, and creatives.

Features:
- Responsive layout
- Modern design
- Google Fonts
- Project showcase section
- Easy to customize

Instructions:
1. Open index.html in any browser.
2. Edit the content inside index.html and style.css to personalize.
3. Use live server extension for preview during development.

Made by: Your Name
Email: your@email.com
